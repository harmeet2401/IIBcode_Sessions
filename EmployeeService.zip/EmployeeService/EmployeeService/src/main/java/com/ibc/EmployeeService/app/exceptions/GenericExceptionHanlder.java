package com.ibc.EmployeeService.app.exceptions;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.context.request.WebRequest;
import org.springframework.web.servlet.mvc.method.annotation.ResponseEntityExceptionHandler;

import javax.net.ssl.HttpsURLConnection;
import java.util.Date;

@ControllerAdvice
@RestController
public class GenericExceptionHanlder extends ResponseEntityExceptionHandler {
    /**
     * This function will handle all the exceptions comes in all controller
     * @param ex
     * @param request
     * @return
     */
    @ExceptionHandler(Exception.class)
    public final ResponseEntity<Object> genericExceptionHandleForEmployees(Exception ex, WebRequest request)  {
        ExceptionStructure responseBean =new ExceptionStructure("Internal Server Error",ex.getMessage(),new Date());
        return new ResponseEntity(responseBean,HttpStatus.INTERNAL_SERVER_ERROR);
    }

    @ExceptionHandler(EmployeeNotFoundException.class)
    public final ResponseEntity<Object> EmployeeNotFoundHandler(Exception ex, WebRequest request)  {
        ExceptionStructure responseBean =new ExceptionStructure("UserNotFoundException",ex.getMessage(),new Date());
        return new ResponseEntity(responseBean,HttpStatus.NOT_FOUND);
    }


}

