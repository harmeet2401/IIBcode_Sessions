package com.ibc.EmployeeService.app;

import com.ibc.EmployeeService.ObjModel.EmployeeObjects;
import org.springframework.stereotype.Component;

import java.util.ArrayList;
import java.util.List;

/**
 * This class will help in manipulating the employee data that is set up using the employee bean named: EmployeeObjects
 */
@Component // or either a service
public class EmployeeDOA {
    public List<EmployeeObjects> list;

    public List<EmployeeObjects> getList() {
        return list;
    }

    public void setList(List<EmployeeObjects> list) {
        this.list = list;
    }

    {
        list = new ArrayList<>();
        list.add(new EmployeeObjects("Simranjeet Singh","Mohan nagar","9982195509",1));
        list.add(new EmployeeObjects("Harmeet Singh","Rajouri garden","7982195509",2));
        list.add(new EmployeeObjects("Harmeet Singh","GGT Garden","7082195509",3));
        list.add(new EmployeeObjects("Harmeet Singh","Kailash Garden","7002195509",4));

    }

    /**
     *
     * @return
     */
    public List<EmployeeObjects> retriveAllEmployee(){
        return this.getList();
    }

    /**
     *
     * @param id
     * @return
     */
    public  EmployeeObjects getEmployee(int id){
        for(EmployeeObjects emp : list){

            if(emp.getEmpid() == id){

                return emp;
            }
        }

        return null;
    }

    /**
     *
     * @param id
     */
    public  EmployeeObjects deleteEmployee(int id){
        for(EmployeeObjects emp : list){

            if(emp.getEmpid() == id){

                list.remove(emp);
                return emp;
            }
        }

    return null;
    }

    /**
     *
     */
    public  void deleteEmployees(){
       list.removeAll(list);

    }

    /**
     *
     * @param emp
     */
    public  EmployeeObjects addEmployee(EmployeeObjects emp){
          emp.setEmpid(list.size()+1);
         list.add(emp);
         return emp;

    }
}

