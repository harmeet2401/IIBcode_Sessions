package com.ibc.EmployeeService.ObjModel;

import javax.persistence.GeneratedValue;
import javax.persistence.Id;

public class EmployeeObjects {
    String empname;
    String empadd;
    String emptel;

    @Id
    @GeneratedValue
    int empid;

    protected EmployeeObjects(){

    }
    public String getEmpname() {
        return empname;
    }

    public void setEmpname(String empname) {
        this.empname = empname;
    }

    public String getEmpadd() {
        return empadd;
    }

    public void setEmpadd(String empadd) {
        this.empadd = empadd;
    }

    public String getEmptel() {
        return emptel;
    }

    public void setEmptel(String emptel) {
        this.emptel = emptel;
    }

    public int getEmpid() {
        return empid;
    }

    public void setEmpid(int empid) {
        this.empid = empid;
    }

    public EmployeeObjects(String empname, String empadd, String emptel, int empid) {
        this.empname = empname;
        this.empadd = empadd;
        this.emptel = emptel;
        this.empid = empid;
    }

}
