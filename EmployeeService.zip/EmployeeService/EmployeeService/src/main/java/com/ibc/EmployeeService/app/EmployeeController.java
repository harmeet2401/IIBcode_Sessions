package com.ibc.EmployeeService.app;

import com.ibc.EmployeeService.ObjModel.EmployeeObjects;
import com.ibc.EmployeeService.app.exceptions.EmployeeNotFoundException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.support.ServletUriComponentsBuilder;
import java.net.URI;
import java.nio.file.attribute.UserPrincipalNotFoundException;
import java.util.List;
import java.util.Objects;


@RestController
public class EmployeeController {

    @Autowired
    public EmployeeDOA employeeDOA;

    /**
     *To get all employee for an associated  data from memory
     * @return
     */
    @GetMapping(path = "/emps")
    private List<EmployeeObjects> getAllmployees(){

        return employeeDOA.retriveAllEmployee();
    }

    /**
     *To get all employee for an associated ID data from memory
     * @param id
     * @return
     */
    @GetMapping(path = "/emps/{id}")
    private EmployeeObjects getEmp(@PathVariable  int id){

        EmployeeObjects emp = employeeDOA.getEmployee(id);
        if (Objects.nonNull(emp)) {
            return emp;
        } else {
            throw new EmployeeNotFoundException("Id:- " + id);
        }

    }

    /**
     *To remove all employee for an associated ID data from memory
     * @param id
     */
    @PutMapping(path = "/emps/{id}")
    private EmployeeObjects removeEmp(@PathVariable  int id){

        EmployeeObjects empobj =employeeDOA.deleteEmployee(id);
        if(empobj==null){
            throw new EmployeeNotFoundException("Can not deletee id:- " + id + "not existing");
        }
        return empobj;
    }

    /**
     * To remove all employees data from memory
     */
    @PutMapping(path = "/emps")
    private void removeEmps(){

        employeeDOA.deleteEmployees();
    }

    @PostMapping(path = "/emps")
    private ResponseEntity addEmp(@RequestBody EmployeeObjects emp){

       EmployeeObjects empobj =  employeeDOA.addEmployee(emp);
        URI location = ServletUriComponentsBuilder.fromCurrentRequest().path("/{id}").build(empobj.getEmpid());
        return ResponseEntity.created(location).build();
    }
}
