package com.mypractice.Coding.practice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CodingPracticeApplicationTests {

	@Test
	void contextLoads() {
	}

}
