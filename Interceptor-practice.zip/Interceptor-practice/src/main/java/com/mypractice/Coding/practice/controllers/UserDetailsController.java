package com.mypractice.Coding.practice.controllers;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class UserDetailsController {

    @GetMapping(path = "/users/hello")
    public String helloWorld(){
        return "Hello from the world";
    }

}
