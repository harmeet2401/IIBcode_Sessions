package com.mypractice.Coding.practice.practiceClasses;

public class FibonacciSeries {
    public static int fibonacci(int n) {
        // Create an array to store Fibonacci numbers
        int[] fib = new int[n + 1];

        // Base cases
        fib[0] = 0;
        fib[1] = 1;

        // Calculate Fibonacci numbers using dynamic programming
        for (int i = 2; i <= n; i++) {
            fib[i] = fib[i - 1] + fib[i - 2];
        }
        for (int i : fib) {
            System.out.print(" " + i);
        }

        // Return the nth Fibonacci number
        return fib[n];
    }

    public static void main(String[] args) {
        int n = 10; // Calculate the 10th Fibonacci number
        int fibonacciNumber = fibonacci(n);
        System.out.println("The " + n + "th Fibonacci number is: " + fibonacciNumber);
    }
}

