package com.mypractice.Coding.practice;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import java.util.*;
import java.util.stream.Collectors;
import java.util.stream.IntStream;

@SpringBootApplication
public class CodingPracticeApplication {

	public static void main(String[] args) {
		SpringApplication.run(CodingPracticeApplication.class, args);
		//int max = Math.max(1,2);
		//firstNonRepeatingChar();
	}


	/**
	 * Save the occurence of each character in linkedhashmap and then fetch the key with 1 occurence from the linkedHashmap
	 * FindFirst works along with filter so first filter the records and then get the first
	 */

	public static void firstNonRepeatingChar(){
		List<String> list = Arrays.asList("Harmeet Singh","yh","run","run", "game");
		Set<String> set= list.stream().collect(Collectors.toSet());
		List<String> l = list.stream().distinct().collect(Collectors.toList());

		List<Integer> li = list
				.stream()
				.map(String::length)
				.sorted(Comparator.naturalOrder())
				.collect(Collectors.toList());

		int n  = 6;
		IntStream.rangeClosed(1, n)
				.reduce(1, (a, b) -> a * b);
		System.out.println("Duplicate removed : "+ li);
		String str = "upinderkaur";
		Map<String , Integer> map = new LinkedHashMap<>();
		for (char c : str.toCharArray()) {
			String strBuild = String.valueOf(c);
			if(map.get(strBuild)!=null){
			if(str.contains(strBuild)){
				map.put(strBuild,map.get(strBuild)+1);
			}
			}else{
				map.put(strBuild,1);
			}
		}
		map.entrySet().forEach(System.out::println);
		System.out.println("The first char which is non repeatable  "+map.entrySet().stream().filter(e->e.getValue()==1).findFirst().get());
		Integer st  = list.stream().map(String::length).sorted(Comparator.reverseOrder()).findFirst().get();
				Integer st1 = list.stream().mapToInt(s->s.length()).max().getAsInt();
		Double f = list.stream().mapToInt(s->s.length()).average().getAsDouble();
		System.out.println("Longest string length : "+ st + " "+st1+ " "+f);
	}
	public static void nestedLoop()
	{

		/**
		 * loop inside loop is like stream inside the stream.
		 * Flatmap ka kaam hai elements ko combine krna
		 * below code mai map jo Stream of list return krra hai usko
		 * flatmap combine krra hai
		 */
		List<Integer> list1 = Arrays.asList(1, 2, 3);
		List<Integer> list2 = Arrays.asList(4, 5, 6);
		List<List<Integer>> pairs = list1.stream()
				//	.map(i->list2.stream().map(j->Arrays.asList(i,j)))
				.flatMap(i->list2.stream().map(j->Arrays.asList(i,j)))
				.peek(System.out::println)
				.collect(Collectors.toList());
		System.out.println(pairs);

		String str1= "ana";
		String palidrome =str1
				.chars()
				.mapToObj(i -> (char) i)
				.map(String::valueOf)
				.peek(System.out::println)
				.sorted(Comparator.reverseOrder())
				.peek(System.out::print)
				.collect(Collectors.joining())
				.equalsIgnoreCase(str1) ? "PALIDROME" : "NOT A PALIDROME";

		System.out.println("");
		System.out.println(palidrome);
	}
	public static void palindrome (){
		String str = "ana";
		System.out.println(str.length()/2);
		boolean isPalindrome = IntStream.range(0, str.length() / 2)
				.allMatch(i -> str.charAt(i) == str.charAt(str.length() - i - 1));

		if (isPalindrome) {
			System.out.println(str + " is a palindrome.");
		} else {
			System.out.println(str + " is not a palindrome.");
		}


	}

}
