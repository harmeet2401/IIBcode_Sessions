package com.mypractice.Coding.practice.practiceClasses;

import java.util.Comparator;
import java.util.LinkedList;
import java.util.stream.Collectors;

public class MaximumSubarraySum {
    public static int maxSubarraySum(int[] nums) {
        int maxEndingHere = nums[0];
        int maxSoFar = nums[0];

        for (int i = 1; i < nums.length; i++) {
            maxEndingHere = Math.max(nums[i], maxEndingHere + nums[i]);
            maxSoFar = Math.max(maxSoFar, maxEndingHere);
        }

        return maxSoFar;
    }

    public static void main(String[] args) {
        int[] nums = { 5,5,1,1,2,22};
        int maxSum = maxSubarraySum(nums);
        int maxNumber = maxNumber(nums);
        //int[] numsOut= rotateArray(nums , 3);
        System.out.println("Maximum subarray sum: " + maxSum);
        System.out.println("Maximum num: " + maxNumber);
        reverseLinkedList();
        //System.out.println("Rotated num: " + numsOut);
    }

    public static int maxNumber(int[] nums){
        int maxNum = 0;
        for (int i = 0; i < nums.length-1; i++) {
            if(nums[i]>nums[i+1]){
                maxNum = nums[i];
            }else{
                maxNum = nums[i+1];
            }
        }
        return maxNum;
    }

    public static int[] rotateArray(int[] nums , int nRotate){
        //{-2, 1, -3, 4, -1, 2, 1, -5, 4};
        for (int i = 0; i < nums.length-1; i++) {
            nums[i+nRotate] = nums[i];
        }
        return nums;
    }

    public static void reverseLinkedList(){
        LinkedList<Integer> list = new LinkedList<>();
        list.add(5);
        list.add(2);
        list.add(1);
        list.add(4);
        System.out.println(list.stream().sorted(Comparator.reverseOrder()).collect(Collectors.toList()));
        //OR
    }
}
