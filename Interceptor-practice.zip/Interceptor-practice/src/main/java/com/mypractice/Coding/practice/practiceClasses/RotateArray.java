package com.mypractice.Coding.practice.practiceClasses;

import java.util.Arrays;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.stream.Collectors;

public class RotateArray {
    public static void rotateArray(int[] nums, int k) {
        int n = nums.length;
        k = k % n; // Normalize k if it's larger than the array length

        // Reverse the entire array
        reverse(nums, 0, n - 1);

        // Reverse the first k elements
        reverse(nums, 0, k - 1);

        // Reverse the remaining elements
        reverse(nums, k, n - 1);
    }

    public static void reverse(int[] nums, int start, int end) {
        while (start < end) {
            int temp = nums[start];
            nums[start] = nums[end];
            nums[end] = temp;
            start++;
            end--;
        }


    }

    public static void main(String[] args) {
        int[] nums = {5,5,1,1,2,22};
        int[] nums1 = {5,1,6,4,3,2};
        int k = 2;
        rotateArray(nums, k);

        System.out.println("Rotated array:");
        for (int num : nums) {
          //  System.out.print(num + " ");
        }

        mergeTwoSortedArr(nums,nums1);
    }
    public static void mergeTwoSortedArr(int[] arr1,int[] arr2)
    {

        int arrout[] = new int[arr1.length+arr2.length];
        // merge both the arrays and sort it.
        for (int i = 0; i < arr1.length; i++) {
           arrout[i] = arr1[i];
        }
        int j = arrout.length/2;
        for (int i1 = 0; i1 < arr1.length; i1++) {
            arrout[j] = arr2[i1];
            j++;
        }
        Arrays.stream(arrout).sorted().forEach(n->System.out.print(n+" "));
        findEleNby2Times(arrout);
    }

    public static void findEleNby2Times(int[] args) {
        int occ = args.length/2;
        Map<Integer,Integer> map = new LinkedHashMap<>();
        for (int i = 0; i < args.length; i++) {
            if(map.get(args[i])!=null){
                map.put(args[i],map.get(args[i])+1);
            }else{
                map.put(args[i],1);
            }
        }
        System.out.println("\n");
        map.entrySet().stream().forEach(System.out::println);
        System.out.println("\n");
        map.entrySet().stream().filter(e->e.getValue()==occ).collect(Collectors.toList());

    }
}
