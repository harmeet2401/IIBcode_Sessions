package com.mypractice.Coding.practice.config;

import com.mypractice.Coding.practice.interceptor.LoggingFilter;
import org.springframework.boot.web.servlet.FilterRegistrationBean;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class FilterConfig {

    /**
     * This will create a bean and will add that as part of the classpath to be used in filtering
     * Below code shows that any request coming to /users/* will be intercepted before the
     * dispatcher servlet sends it further to controller
     * and we can do anything with it in LoggingFilter Class related for filter.
     * we can block it , send it or anything with it.
     * @return
     */
    @Bean
    public FilterRegistrationBean<LoggingFilter> loggingFilter() {
        FilterRegistrationBean<LoggingFilter> registrationBean = new FilterRegistrationBean<>();
        registrationBean.setFilter(new LoggingFilter());
        registrationBean.addUrlPatterns("/users/*"); // Apply the filter to all URL patterns
        return registrationBean;
    }
}

