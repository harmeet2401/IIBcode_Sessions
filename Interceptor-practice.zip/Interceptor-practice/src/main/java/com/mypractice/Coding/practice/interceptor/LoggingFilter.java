package com.mypractice.Coding.practice.interceptor;
import jakarta.servlet.Filter;
import jakarta.servlet.FilterChain;
import jakarta.servlet.FilterConfig;
import jakarta.servlet.ServletException;
import jakarta.servlet.ServletRequest;
import jakarta.servlet.ServletResponse;
import jakarta.servlet.http.HttpServletResponse;

import javax.servlet.*;
import java.io.IOException;

public class LoggingFilter implements jakarta.servlet.Filter {


        @Override
        public void init(FilterConfig filterConfig) throws ServletException {
                Filter.super.init(filterConfig);
        }

        @Override
        public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain)
                throws IOException, ServletException {
                // Check condition to block request (for example, based on request parameters or headers)
                if (shouldBlock(request)) {
                        // Send an HTTP response indicating that the request is blocked
                        HttpServletResponse httpResponse = (HttpServletResponse) response;
                        httpResponse.sendError(HttpServletResponse.SC_FORBIDDEN, "Request Blocked");
                } else {
                        // Continue the filter chain for non-blocked requests
                        chain.doFilter(request, response);
                }
        }

        private boolean shouldBlock(ServletRequest request) {
                // Implement your logic to determine whether the request should be blocked
                // For example, check request parameters, headers, or any other condition
                // Return true if the request should be blocked, false otherwise
                return false; // Modify this condition based on your requirement
        }

        @Override
        public void destroy() {
                Filter.super.destroy();
        }
}
