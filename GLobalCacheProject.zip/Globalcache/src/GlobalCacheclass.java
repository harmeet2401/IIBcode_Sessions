import com.ibm.broker.plugin.MbException;
import com.ibm.broker.plugin.MbGlobalMap;


public class GlobalCacheclass {
	public static String mapname = "GCMAP";
	public static  void LoadValueInCache(String key , byte [] val){
		try {
			MbGlobalMap map = MbGlobalMap.getGlobalMap(mapname);
			if(map.containsKey(key)){
				map.update(key, val);
			}else{
				map.put(key, val);
			}
			
		} catch (MbException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			
		}
		
	}
	
	public static byte[] GetValueFromCache(String Key){
		MbGlobalMap map;
		byte[] val = null;
		try {
			map = MbGlobalMap.getGlobalMap(mapname);
			val = (byte[]) (map.get(Key));
		} catch (MbException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return val ;
	}

}
