import com.ibm.broker.plugin.MbException;
import com.ibm.broker.plugin.MbGlobalMap;


public class gc {

	public static String mapname = "GBMAP";
	/**
	 * 
	 * @param Key
	 * @param xml
	 * @return boolean
	 */
	public static boolean LoadValueTocache(String Key , Byte[] xml){
		
		try {
			MbGlobalMap map = MbGlobalMap.getGlobalMap(mapname); 
			
			if(map.containsKey(Key)){
				map.update(Key, xml);
			}else{
				map.put(Key, xml);
			}
			
		} catch (MbException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return false;
		}
		return true;
		
	}
	
	/**
	 * 
	 * @param Key
	 * @return Byte[]
	 */
	public static Byte[] GetValueFromCache(String Key){

		try {
			MbGlobalMap map = MbGlobalMap.getGlobalMap(mapname); 
			map.get(Key);
		} catch (MbException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return null;
		
		
	}
}
