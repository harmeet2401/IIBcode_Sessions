package com.in28minutes.microservice.limitsservice.controller;

import com.in28minutes.microservice.limitsservice.config.configurations;
import com.in28minutes.microservice.limitsservice.limitbean.limits;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class limitcontoller {

    @Autowired
    private configurations configuration;
    @GetMapping(path = "/limits")
    public limits getlimits(){
        return new limits(configuration.getMinimum(),configuration.getMaximum());
    }
}
