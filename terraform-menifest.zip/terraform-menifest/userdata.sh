#!/bin/bash
sudo yum update -y
sudo yum install -y httpd
sudo systemctl start httpd
sudo systemctl enable httpd
sudo chmod 777 /var/www/html
sudo echo "Hello from the terraform Ec2 instance" > /var/www/html/index.html