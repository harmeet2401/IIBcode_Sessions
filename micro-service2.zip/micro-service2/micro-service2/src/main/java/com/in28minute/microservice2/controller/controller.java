package com.in28minute.microservice2.controller;

import com.in28minute.microservice2.bean.mybean;
import com.in28minute.microservice2.config.myconfig;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class controller {
    @Autowired
    private myconfig config;
    @GetMapping(path = "/getvalue")
    public mybean getbean(){
        return new mybean(config.getUsername(), config.getPassword(), config.getDept(), config.getAddress());
    }
}
