package com.in28minute.microservice2.bean;

public class mybean {
    private String username;
    private String password;
    private String dept;
    private String address;
    @Override
    public String toString() {
        return "mybean{" +
                "username='" + username + '\'' +
                ", password='" + password + '\'' +
                ", dept='" + dept + '\'' +
                ", address='" + address + '\'' +
                '}';
    }


    public mybean(String username, String password, String dept, String address) {
        this.username = username;
        this.password = password;
        this.dept = dept;
        this.address = address;
    }


    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public String getDept() {
        return dept;
    }

    public void setDept(String dept) {
        this.dept = dept;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }


}
