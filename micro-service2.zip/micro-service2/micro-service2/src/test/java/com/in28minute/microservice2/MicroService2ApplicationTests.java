package com.in28minute.microservice2;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MicroService2ApplicationTests {

	@Test
	void contextLoads() {
	}

}
