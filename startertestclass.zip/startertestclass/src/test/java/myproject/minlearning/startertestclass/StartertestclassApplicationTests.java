package myproject.minlearning.startertestclass;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class StartertestclassApplicationTests {

	@Test
	void contextLoads() {
	}

}
