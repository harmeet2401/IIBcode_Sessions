package com.in28minutes.microservices.currencyexchangeservice;

import org.springframework.data.jpa.repository.JpaRepository;

public interface CurrencyExRepo extends JpaRepository<CurrencyExchnage , Long> {
   CurrencyExchnage findByFromAndTo(String from , String to);
}
