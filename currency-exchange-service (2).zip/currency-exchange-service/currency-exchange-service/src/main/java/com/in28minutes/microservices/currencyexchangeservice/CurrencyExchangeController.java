package com.in28minutes.microservices.currencyexchangeservice;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class CurrencyExchangeController {

    @Autowired
    Environment environment;

    @Autowired
    CurrencyExRepo currencyExRepo;

    @GetMapping(path = "/currency-exchange/from/{from}/to/{to}")
    public CurrencyExchnage getExchnageValue(@PathVariable String from , @PathVariable String to){

        //CurrencyExchnage currencyExchnage =   new CurrencyExchnage(1000l,"USD","IND", BigDecimal.valueOf(65.00) );
        CurrencyExchnage currencyExchnage = currencyExRepo.findByFromAndTo(from,to);
        String port =environment.getProperty("local.server.port");
        currencyExchnage.setEnvironment(port);
        return currencyExchnage;

    }
}
