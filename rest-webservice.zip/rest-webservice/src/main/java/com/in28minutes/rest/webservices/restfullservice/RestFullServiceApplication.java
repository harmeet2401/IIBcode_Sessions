package com.in28minutes.rest.webservices.restfullservice;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class RestFullServiceApplication {

	public static void main(String[] args) {
		SpringApplication.run(RestFullServiceApplication.class, args);
	}

}
