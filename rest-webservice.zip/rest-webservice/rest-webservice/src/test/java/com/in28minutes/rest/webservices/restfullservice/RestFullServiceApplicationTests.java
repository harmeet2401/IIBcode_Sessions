package com.in28minutes.rest.webservices.restfullservice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RestFullServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
