package com.in28minutes.rest.webservices.restfullservice.controllers;


import com.in28minutes.rest.webservices.restfullservice.bean.User;
import com.in28minutes.rest.webservices.restfullservice.exceptionhanlders.UserNotCreatedException;
import com.in28minutes.rest.webservices.restfullservice.exceptionhanlders.UserNotFoundException;
import com.in28minutes.rest.webservices.restfullservice.serviceDAO.UserServiceDAO;
import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.MessageSource;
import org.springframework.context.i18n.LocaleContextHolder;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.support.ServletUriComponentsBuilder;


import java.net.URI;
import java.util.List;
import java.util.Locale;

@RestController
@RequestMapping(path = "/basepath")
public class UserController {


    public MessageSource messageSource;

    public UserController(MessageSource messageSource){
        this.messageSource = messageSource;
    }

    @Autowired
    public UserServiceDAO userServiceDAO;

    @GetMapping(path = "/users")
    public List<User> getAllUsers(){
        return userServiceDAO.findAll();
    }

    @GetMapping(path = "/users/{id}")
    public User getUser(@PathVariable int id){
        User user = userServiceDAO.findOne(id);
        if (user==null) {
            throw new UserNotFoundException("User id not found for :- " + id);
        }
        return user;

    }

    /**
     * Below post mapping is creating an object so we need to send correct http response code of 201
     * which is for object created
     * So return a ResponseEntity object in place of a string return
     * @param user
     * @return
     */
    @PostMapping(path = "/users")
    public ResponseEntity<Object> PostUser(@Valid @RequestBody User user ){
        if(userServiceDAO.saveUser(user)!=null){
            //return ResponseEntity.created(null).body("User created with id : - "+user.getId());
            URI location = ServletUriComponentsBuilder.fromCurrentRequest().path("/{id}").buildAndExpand(user.getId()).toUri();
            return ResponseEntity.created(location).body("!!! User Created !!!");
        }/*else{
            throw new UserNotCreatedException("User Not created :- " + user.getName());
        }*/
        return ResponseEntity.internalServerError().build();
    }

    @DeleteMapping(path = "/users/remove/{id}")
    public String removeUser(@PathVariable int id){
        return userServiceDAO.deleteUserByID(id);
    }

    @GetMapping(path = "/internationalization")
    public String sendInternationlizationMessage(){
        Locale locale= LocaleContextHolder.getLocale();
        return messageSource.getMessage("good.morning.message",null,null,locale);
    }
}
