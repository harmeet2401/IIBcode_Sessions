package com.kafka.producer;
import com.kafka.producer.MultiplePrints;

public class HelloWorld extends  MultiplePrints{
    public static MultiplePrints multipleprints;

}
