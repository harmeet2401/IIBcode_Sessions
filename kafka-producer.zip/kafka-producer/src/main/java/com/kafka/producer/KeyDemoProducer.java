package com.kafka.producer;

import org.apache.kafka.clients.producer.*;
import org.apache.kafka.common.serialization.IntegerSerializer;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import java.util.Properties;
import org.apache.kafka.clients.producer.ProducerConfig;

/**
 * below code will publish the message in key space value format
 * we can also set the separator for the key value pair , need to find out.
 */
public class KeyDemoProducer {

    public static void main(String Arg[]) {
        final Logger logger = LoggerFactory.getLogger(KeyDemoProducer.class);
        String bootstapserver = "127.0.0.1:9092";
        Properties properties = new Properties();
        properties.setProperty(ProducerConfig.BOOTSTRAP_SERVERS_CONFIG, bootstapserver);
        properties.setProperty(ProducerConfig.KEY_SERIALIZER_CLASS_CONFIG, IntegerSerializer.class.getName());
        properties.setProperty(ProducerConfig.VALUE_SERIALIZER_CLASS_CONFIG, IntegerSerializer.class.getName());
        KafkaProducer<Integer, Integer> producer = new KafkaProducer<>(properties);
        String topic = "first_topic";
        for (int i = 20; i < 30; i++) {
            //String value = "Hello-world" + Integer.toString(i);
            //String key = "Id_" + Integer.toString(i);
            ProducerRecord<Integer, Integer> record = new ProducerRecord<Integer, Integer>(topic, i, i);
            logger.info("key : " + i);

            producer.send(record, new Callback() {
                @Override
                public void onCompletion(RecordMetadata metadata, Exception exception) {

                    if (exception == null) {

                        logger.info("Topic: " + metadata.topic() + "\n" +
                                "Partition: " + metadata.partition() + "\n" +
                                "Offset: " + metadata.offset() + "\n" +
                                "SerializedKey: " + metadata.serializedKeySize() + "\n" +
                                "TimeStamp: " + metadata.timestamp());

                    }
                    else {
                        logger.error("Error while producing", exception);
                    }
                }
            });

        }
        producer.flush();
        producer.close();

    }
}
