package com.kafka.producer;

import org.apache.kafka.clients.producer.KafkaProducer;
import org.apache.kafka.clients.producer.Producer;
import org.apache.kafka.clients.producer.ProducerConfig;
import org.apache.kafka.clients.producer.ProducerRecord;
import org.apache.kafka.common.serialization.StringSerializer;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.Properties;

public class TransactionalClass {
    final Logger logger = LoggerFactory.getLogger(TransactionalClass.class);
    public static void transactionIDFn(String arg[]){

        String bootstrapserver = "127.0.0.1:9092";
        Properties properties = new Properties();
        properties.put("tranactional.id","my-transactional-id");
        properties.put("acks","all"); // This will activate the all ack algo for leader to wait for the acks from the followers post replication.
        properties.put(ProducerConfig.BOOTSTRAP_SERVERS_CONFIG,bootstrapserver);
        properties.put(ProducerConfig.KEY_SERIALIZER_CLASS_CONFIG, StringSerializer.class.getName());
        properties.put(ProducerConfig.VALUE_SERIALIZER_CLASS_CONFIG,StringSerializer.class.getName());

        KafkaProducer<String , String> producer = new KafkaProducer<String, String>(properties);
        String topic = "first_topic";
        //producer.initTransactions();
        for(int i = 0;i<10;i++) {
          //  producer.beginTransaction();
            ProducerRecord<String, String> producerrecord = new
                    ProducerRecord<>(topic, Integer.toString(i)
                    , "MyTransaction"+Integer.toString(i));
            producer.send(producerrecord);
            //producer.commitTransaction();

        }
        //producer.abortTransaction();
        producer.flush();
        producer.close();




    }
}
