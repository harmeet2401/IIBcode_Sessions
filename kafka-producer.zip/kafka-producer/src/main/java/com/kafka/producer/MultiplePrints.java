package com.kafka.producer;

public class MultiplePrints {

    public void printhelloworld(){
        for (int i = 0 ; i <10 ;i ++){
            System.out.println("Hello-world"+Integer.toString(i));
        }


    }
}
