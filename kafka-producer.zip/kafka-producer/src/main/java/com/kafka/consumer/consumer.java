package com.kafka.consumer;

import com.fasterxml.jackson.databind.DeserializationConfig;
import org.apache.kafka.clients.consumer.ConsumerConfig;
import org.apache.kafka.clients.consumer.ConsumerRecord;
import org.apache.kafka.clients.consumer.ConsumerRecords;
import org.apache.kafka.clients.consumer.KafkaConsumer;
import org.apache.kafka.clients.producer.ProducerConfig;
import org.apache.kafka.common.serialization.IntegerDeserializer;
import org.apache.kafka.common.serialization.IntegerSerializer;
import org.apache.kafka.common.serialization.StringDeserializer;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.lang.reflect.Array;
import java.time.Duration;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Properties;

/**
 * This program will read the messages from the topic and print key & value randomly
 */
public class consumer {
    public static void main(String args[]){
        final Logger logger = LoggerFactory.getLogger(consumer.class);

        // first set the properties for kafka consumer objects
        Properties properties = new Properties();
        properties.put(ConsumerConfig.BOOTSTRAP_SERVERS_CONFIG,"127.0.0.1:9092");
        properties.put(ConsumerConfig.KEY_DESERIALIZER_CLASS_CONFIG, IntegerDeserializer.class.getName());
        properties.put(ConsumerConfig.VALUE_DESERIALIZER_CLASS_CONFIG,IntegerDeserializer.class.getName());
        properties.put(ConsumerConfig.GROUP_ID_CONFIG,"PHEOENIX");
        properties.put(ConsumerConfig.AUTO_OFFSET_RESET_CONFIG,"earliest");
        KafkaConsumer<Integer , Integer > consumer = new KafkaConsumer<Integer, Integer>(properties);
        consumer.subscribe(Arrays.asList("first_topic"));
        while(true){

            ConsumerRecords<Integer, Integer> consumerRecord = consumer.poll(Duration.ofMillis(100));

            for( ConsumerRecord<Integer , Integer> rec : consumerRecord){

                logger.info("Key:-"+rec.key() +"   "+ "value:-"+rec.value() + "  "+"Offset : -"+rec.offset()+" "+" Partition : - "+rec.partition());


            }

        }






    }
}
