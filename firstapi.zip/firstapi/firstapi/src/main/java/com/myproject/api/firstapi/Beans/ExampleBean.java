package com.myproject.api.firstapi.Beans;

import org.springframework.http.ResponseEntity;

public class ExampleBean  {
    private String Name;
    private String Address;
    private String Dept;

    @Override
    public String toString() {
        return "ExampleBean{" +
                "Name='" + Name + '\'' +
                ", Address='" + Address + '\'' +
                ", Dept='" + Dept + '\'' +
                '}';
    }




    public String getName() {
        return Name;
    }

    public void setName(String name) {
        Name = name;
    }

    public String getAddress() {
        return Address;
    }

    public void setAddress(String address) {
        Address = address;
    }

    public String getDept() {
        return Dept;
    }

    public void setDept(String dept) {
        Dept = dept;
    }


    public ExampleBean(String name, String address, String dept) {
        Name = name;
        Address = address;
        Dept = dept;
    }



}
