package com.myproject.api.firstapi.CustomException;

public class UserNOtFoundException extends RuntimeException {
    public UserNOtFoundException(String s) {
        super(s);
    }
}
