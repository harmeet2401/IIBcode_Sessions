package com.myproject.api.firstapi.processorDOA;
import com.myproject.api.firstapi.Beans.CustomExceptionClass;
import com.myproject.api.firstapi.Beans.ExampleBean;
import org.springframework.stereotype.Service;
import javax.annotation.PostConstruct;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;

@Service
public class ExampleDOA {

    public List<ExampleBean> elist = new ArrayList<>();

    @PostConstruct
    public void setList(){
        for(int i = 0; i <4; i ++) {
            elist.add(i, new ExampleBean("Harmeet Singh "+Integer.toString(i),"Huston"+Integer.toString(i),"IT -"+Integer.toString(i)));
        }
    }

    public List<ExampleBean> retrieveAllUsers(){
        return elist;
    }

    public void removeAllUsers(){
        elist.removeAll(elist);
    }
    public ExampleBean addUser(ExampleBean exbean) {

        for (ExampleBean exampleBean : elist) {
            if (exampleBean.getName().equalsIgnoreCase(exbean.getName())) {
                return null;
            }
        }
        elist.add(exbean);
        return exbean;
    }
    public ExampleBean retrieveUser(String name){
        for(ExampleBean exampleBean : elist){
            if(exampleBean.getName().contains(name)){
                return exampleBean;
            }
        }
        return  null;
    }

    /*public CustomExceptionClass sendCustonException(String fieldname,String exmessage , String excode){
        Date date = Calendar.getInstance ().getTime ();
        try {
            date = new SimpleDateFormat("yyyy-mm-dd hh:mm:ss").parse(date.toString());
        } catch (ParseException e) {
            e.printStackTrace();
        }
        return new CustomExceptionClass("User Not found: - "+fieldname,"1009",date);
    }*/



}
