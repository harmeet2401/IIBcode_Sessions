package com.myproject.api.firstapi.controller;

import com.myproject.api.firstapi.Beans.CustomExceptionClass;
import com.myproject.api.firstapi.Beans.ExampleBean;
import com.myproject.api.firstapi.CustomException.UserNOtFoundException;
import com.myproject.api.firstapi.processorDOA.ExampleDOA;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
public class ApiContoller {

    @Autowired
    ExampleDOA exampleDOA;

    @GetMapping(path = "/hello")
    public String hello(){
        return "hello - world";
    }

    @GetMapping(path = "/getbean")
    public ExampleBean getBean(){
        return new ExampleBean("Harmeet Singh","Huston","IT");

    }

    @GetMapping(path = "/deleteAll")
    public void removeAllUsers(){
        exampleDOA.removeAllUsers();

    }

    @GetMapping(path = "/getAllUsers")
    public List<ExampleBean> getAllUsers(){
        return exampleDOA.retrieveAllUsers();

    }

    @PostMapping(path = "/addUser")
    public ExampleBean addUser(@RequestBody ExampleBean exampleBean){
       return exampleDOA.addUser(exampleBean);
    }

    @GetMapping(path = "/getUser/{name}")
    public ResponseEntity<? extends Object> retrieve (@PathVariable String name){
        ExampleBean exampleBean =  exampleDOA.retrieveUser(name);
        if (exampleBean == null) {
            throw new UserNOtFoundException("User not found - "+name);
            }
        return new ResponseEntity<>(exampleBean, HttpStatus.FOUND);
    }
}
