package com.myproject.api.firstapi.Beans;

import java.util.Date;

public class CustomExceptionClass {
    private String exmessage;
    private String excode;
    private Date exdate;
    @Override
    public String toString() {
        return "CustomExceptionClass{" +
                "exmessage='" + exmessage + '\'' +
                ", excode='" + excode + '\'' +
                ", exdate=" + exdate +
                '}';
    }



    public String getExmessage() {
        return exmessage;
    }

    public void setExmessage(String exmessage) {
        this.exmessage = exmessage;
    }

    public String getExcode() {
        return excode;
    }

    public void setExcode(String excode) {
        this.excode = excode;
    }

    public Date getExdate() {
        return exdate;
    }

    public void setExdate(Date exdate) {
        this.exdate = exdate;
    }


    public CustomExceptionClass(String exmessage, String excode, Date exdate) {
        this.exmessage = exmessage;
        this.excode = excode;
        this.exdate = exdate;
    }




}
