package com.myproject.api.firstapi.processorDOA;

import com.myproject.api.firstapi.Beans.CustomExceptionClass;
import com.myproject.api.firstapi.CustomException.UserNOtFoundException;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.mvc.method.annotation.ResponseEntityExceptionHandler;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

@RestController
@ControllerAdvice
public class CustomResponseEntityException extends ResponseEntityExceptionHandler {

    /**
     * It means if any instance of UserNotFoundException class is created/throwed from any of the controller in project this
     * will catch it
     * This function will return the ResponseEntity as a object type as return param
     * @return
     */
    @ExceptionHandler(UserNOtFoundException.class)
   public ResponseEntity<? extends Object> sendExeption(){
        Date date = Calendar.getInstance ().getTime ();
        try {
            date = new SimpleDateFormat("yyyy-mm-dd hh:mm:ss").parse(date.toString());
        } catch (ParseException e) {
            e.printStackTrace();
        }
        CustomExceptionClass exc = new CustomExceptionClass("User not found ","1090",date);
        return new ResponseEntity<>(exc, HttpStatus.NOT_FOUND);
    }

}
