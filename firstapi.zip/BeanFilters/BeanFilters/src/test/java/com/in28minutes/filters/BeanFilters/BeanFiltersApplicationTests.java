package com.in28minutes.filters.BeanFilters;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BeanFiltersApplicationTests {

	@Test
	void contextLoads() {
	}

}
